/**
 * Text-to-speech layer (browser Web Speech API).
 *
 * Structured as its own module so a cloud TTS provider (Azure/Google) can
 * replace it later without touching the rest of the app.
 */

export function speechSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window
}

export interface SpeakOptions {
  rate?: number
  pitch?: number
  lang?: string
}

/** Speak text aloud. Returns false if TTS is unavailable or text is empty. */
export function speak(text: string, opts: SpeakOptions = {}): boolean {
  if (!speechSupported() || !text.trim()) return false
  const synth = window.speechSynthesis
  synth.cancel() // don't queue up stale audio

  const utterance = new SpeechSynthesisUtterance(text)
  utterance.rate = opts.rate ?? 1
  utterance.pitch = opts.pitch ?? 1
  utterance.volume = 1
  utterance.lang = opts.lang ?? 'en-US'

  // Prefer an English voice when available (async list may be empty on first call).
  const voices = synth.getVoices()
  const english = voices.find((v) => v.lang.toLowerCase().startsWith('en'))
  if (english) utterance.voice = english

  synth.speak(utterance)
  return true
}

export function stopSpeech(): void {
  if (speechSupported()) window.speechSynthesis.cancel()
}
