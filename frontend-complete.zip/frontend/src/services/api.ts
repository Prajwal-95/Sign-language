export const API_BASE = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000'
export interface HealthResponse {
  status: string
  environment: string
  model_loaded: boolean
  model_path: string
  num_classes?: number
  version: string
}
export async function checkBackendHealth(timeoutMs = 3000): Promise<HealthResponse | null> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetch(`${API_BASE}/health`, { signal: controller.signal })
    if (!res.ok) return null
    return (await res.json()) as HealthResponse
  } catch {
    return null
  } finally {
    clearTimeout(timer)
  }
}

export interface RecordResult {
  saved: string
  sign: string
  sample_index: number
  frames_used: number
}

/** List the current vocabulary signs from the backend. */
export async function fetchVocab(timeoutMs = 5000): Promise<string[]> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetch(`${API_BASE}/api/vocab`, { signal: controller.signal })
    if (!res.ok) return []
    const data = (await res.json()) as { vocab: string[] }
    return data.vocab ?? []
  } catch {
    return []
  } finally {
    clearTimeout(timer)
  }
}

/** Send one user-recorded landmark sequence to be added to the training data. */
export async function recordSample(
  sign: string,
  frames: { hands: unknown[] }[],
  timeoutMs = 10_000,
): Promise<RecordResult | null> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetch(`${API_BASE}/api/record-sample`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sign, frames }),
      signal: controller.signal,
    })
    if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      throw new Error(err?.detail ?? `HTTP ${res.status}`)
    }
    return (await res.json()) as RecordResult
  } catch (e) {
    throw e instanceof Error ? e : new Error(String(e))
  } finally {
    clearTimeout(timer)
  }
}
