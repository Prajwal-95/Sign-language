import { useCallback, useEffect, useRef, useState } from 'react'
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision'
import { PredictSocket, type Prediction, type SocketStatus } from '../services/ws'
import { speak, stopSpeech, speechSupported } from '../services/tts'

export type RecStatus =
  | 'idle'
  | 'loading-model'
  | 'running'
  | 'paused'
  | 'error'

/**
 * Real-time sign recognition:
 *
 *   webcam video -> MediaPipe HandLandmarker (local, private)
 *     -> compact landmarks -> WebSocket -> backend model
 *     -> prediction -> temporal smoothing (majority window)
 *     -> accepted letter -> sentence buffer -> TTS
 */
const WASM_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm'
const LANDMARKER_URL =
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'

const COOLDOWN_MS = 700 // min time between two accepted signs
const SEND_EVERY = 1 // send every 2nd frame (~30 msg/s)

interface UseSignRecognitionArgs {
  apiBase: string
  videoRef: React.RefObject<HTMLVideoElement | null>
}

export function useSignRecognition({ apiBase, videoRef }: UseSignRecognitionArgs) {
  const [status, setStatus] = useState<RecStatus>('idle')
  const [socketStatus, setSocketStatus] = useState<SocketStatus>('idle')
  const [modelReady, setModelReady] = useState(false)
  const [detectedSign, setDetectedSign] = useState<string | null>(null)
  const [confidence, setConfidence] = useState(0)
  const [sentence, setSentence] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [autoSpeak, setAutoSpeak] = useState(false)
  const [ttsAvailable] = useState<boolean>(speechSupported())

  const landmarkerRef = useRef<HandLandmarker | null>(null)
  const socketRef = useRef<PredictSocket | null>(null)
  const rafRef = useRef<number | null>(null)
  const runningRef = useRef(false)

  const windowRef = useRef<string[]>([])
  const landmarksRef = useRef<number[][][] | null>(null)  // [hand][21][x,y,z] for drawing
  const collectHandsRef = useRef<((hands: unknown[]) => void) | null>(null)
  const lastAcceptedRef = useRef<string | null>(null)
  const lastAcceptTimeRef = useRef(0)
  const frameCounterRef = useRef(0)

  const sentenceRef = useRef('')
  const autoSpeakRef = useRef(false)

  useEffect(() => {
    autoSpeakRef.current = autoSpeak
  }, [autoSpeak])

  const updateSentence = useCallback((next: string) => {
    sentenceRef.current = next
    setSentence(next)
  }, [])

  const resetAcceptState = useCallback(() => {
    windowRef.current = []
    lastAcceptedRef.current = null
    lastAcceptTimeRef.current = 0
    setDetectedSign(null)
    setConfidence(0)
  }, [])

  // ------------------------------------------------------------------ #
  // Called for every prediction received from the backend.
  const onPrediction = useCallback(
    (pred: Prediction) => {
      if (!runningRef.current) return
      if (pred.error) return

      // Segment-based: the backend only sends an accepted sign when the
      // hand was lowered (sign completed). Append it directly — no more
      // guessing on mid-sign frames.
      if (pred.accepted && pred.sign) {
        const sign = pred.sign
        const now = performance.now()
        if (sign === lastAcceptedRef.current) return
        if (now - lastAcceptTimeRef.current < COOLDOWN_MS) return
        lastAcceptedRef.current = sign
        lastAcceptTimeRef.current = now

        const displayWord = sign.replace(/_/g, ' ')
        setDetectedSign(displayWord)
        setConfidence(Math.round(pred.confidence * 100))
        const cur = sentenceRef.current
        const next = cur ? cur + ' ' + displayWord : displayWord
        updateSentence(next)
        if (autoSpeakRef.current) speak(displayWord)
      }
    },
    [updateSentence],
  )

  // ------------------------------------------------------------------ #
  const loop = useCallback(() => {
    if (!runningRef.current) return
    const lm = landmarkerRef.current
    const video = videoRef.current

    if (lm && video && video.readyState >= 2 && video.videoWidth > 0) {
      frameCounterRef.current += 1
      if (frameCounterRef.current % SEND_EVERY === 0) {
        try {
          const res = lm.detectForVideo(video, performance.now())
          landmarksRef.current = (res.landmarks ?? []).map((lmList) =>
            lmList.map((p) => [p.x, p.y, p.z ?? 0]),
          )
          const hands = (res.landmarks ?? []).map((lmList, i) => ({
            handedness: res.handedness?.[i]?.[0]?.categoryName ?? 'Right',
            handedness_score: res.handedness?.[i]?.[0]?.score ?? 1,
            landmarks: lmList.map((p) => [p.x, p.y, p.z ?? 0]),
          }))
          socketRef.current?.sendFrame(hands)
          // If a sample collector is active, feed it the raw hands too.
          collectHandsRef.current?.(hands)
        } catch {
          /* frame not ready yet — skip */
        }
      }
    }
    rafRef.current = requestAnimationFrame(loop)
  }, [videoRef])

  // ------------------------------------------------------------------ #
  const init = useCallback(async () => {
    setError(null)
    setStatus('loading-model')
    try {
      const vision = await FilesetResolver.forVisionTasks(WASM_URL)
      const landmarker = await HandLandmarker.createFromOptions(vision, {
        baseOptions: { modelAssetPath: LANDMARKER_URL, delegate: 'CPU' },
        runningMode: 'VIDEO',
        numHands: 2,
      })
      landmarkerRef.current = landmarker
      setModelReady(true)

      socketRef.current = new PredictSocket(apiBase, setSocketStatus, onPrediction)
      socketRef.current.connect()

      runningRef.current = true
      resetAcceptState()
      setStatus('running')
      rafRef.current = requestAnimationFrame(loop)
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      setError('Could not load the hand-tracking model. Check your internet connection: ' + msg)
      setStatus('error')
      setModelReady(false)
    }
  }, [apiBase, loop, onPrediction, resetAcceptState])

  const start = useCallback(() => {
    if (status === 'idle' || status === 'error') void init()
  }, [status, init])

  const pause = useCallback(() => {
    if (status !== 'running') return
    runningRef.current = false
    setStatus('paused')
  }, [status])

  const resume = useCallback(() => {
    if (status !== 'paused') return
    runningRef.current = true
    setStatus('running')
    rafRef.current = requestAnimationFrame(loop)
  }, [status, loop])

  const stop = useCallback(() => {
    runningRef.current = false
    if (rafRef.current !== null) cancelAnimationFrame(rafRef.current)
    rafRef.current = null
    socketRef.current?.close()
    socketRef.current = null
    landmarkerRef.current?.close()
    landmarkerRef.current = null
    setModelReady(false)
    setStatus('idle')
    resetAcceptState()
  }, [resetAcceptState])

  // ------------------------------------------------------------------ #
  // Sentence buffer actions.
  const addSpace = useCallback(() => {
    updateSentence(sentenceRef.current + ' ')
    lastAcceptedRef.current = null
    lastAcceptTimeRef.current = 0
  }, [updateSentence])

  const undo = useCallback(() => {
    updateSentence(sentenceRef.current.slice(0, -1))
  }, [updateSentence])

  const clear = useCallback(() => {
    updateSentence('')
    resetAcceptState()
  }, [updateSentence, resetAcceptState])

  const speakAll = useCallback(() => {
    speak(sentenceRef.current.trim())
  }, [])

  const stopSpeechAll = useCallback(() => {
    stopSpeech()
  }, [])

  // Cleanup on unmount.
  useEffect(() => {
    return () => {
      runningRef.current = false
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current)
      socketRef.current?.close()
      landmarkerRef.current?.close()
    }
  }, [])

  return {
    landmarksRef,
    collectHandsRef,
    status,
    socketStatus,
    modelReady,
    detectedSign,
    confidence,
    sentence,
    error,
    autoSpeak,
    setAutoSpeak,
    ttsAvailable,
    start,
    pause,
    resume,
    stop,
    addSpace,
    undo,
    clear,
    speakAll,
    stopSpeechAll,
  }
}
