import { Link } from 'react-router-dom'
import HandSkeleton from '../components/HandSkeleton'
import GesturePath from '../components/GesturePath'
import Reveal from '../components/Reveal'

const STEPS = [
  {
    title: 'Your hand enters the frame',
    text: 'You raise your hand in front of the webcam. The browser asks for camera permission — and from that moment, frames are processed locally.',
    pose: 'open' as const,
    color: '#22d3ee',
  },
  {
    title: 'MediaPipe extracts 21 landmarks',
    text: 'For every frame, a hand-tracking model finds 21 key points on each hand — fingertips, knuckles, wrist — with depth. That is the glowing skeleton you see on screen.',
    pose: 'point' as const,
    color: '#8b5cf6',
  },
  {
    title: 'Features are normalized',
    text: 'The landmarks are centered on the wrist and scaled by hand size, so the model is insensitive to how close you are or where your hand sits in the frame.',
    pose: 'peace' as const,
    color: '#e879f9',
  },
  {
    title: 'A GRU reads the motion',
    text: 'While your hand is raised, frames accumulate. When you lower your hand, a temporal neural network classifies the whole motion as one of the learned signs.',
    pose: 'fist' as const,
    color: '#fbbf24',
  },
  {
    title: 'The word joins your sentence',
    text: 'The recognized sign is appended to the translation buffer — with a space between words — and can be spoken aloud instantly with a click, or automatically.',
    pose: 'thumb' as const,
    color: '#34d399',
  },
]

export default function HowItWorks() {
  return (
    <div className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="aurora anim-drift" style={{ width: 400, height: 400, left: '-8%', top: '4%', background: 'radial-gradient(circle, rgba(34,211,238,0.16), transparent 70%)' }} />
        <div className="grid-lines" />
      </div>

      <div className="relative mx-auto max-w-3xl px-4 py-16">
        <Reveal className="text-center">
          <span className="kicker">How it works</span>
          <h1 className="mt-3 text-4xl font-extrabold text-white sm:text-5xl">
            Five steps, <span className="text-gradient">one gesture</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-slate-400">
            The entire journey — from your hand moving in front of the camera to a
            spoken word — happens in about two seconds.
          </p>
        </Reveal>

        <div className="mt-14">
          {STEPS.map((step, i) => (
            <Reveal key={step.title} delay={i * 70}>
              <div className="relative flex gap-5">
                {/* connector */}
                {i < STEPS.length - 1 && (
                  <div className="absolute left-[27px] top-16 bottom-[-26px] hidden sm:block" aria-hidden="true">
                    <GesturePath color={step.color} />
                  </div>
                )}
                <div className="relative z-10 hidden h-14 w-14 shrink-0 items-center justify-center sm:flex">
                  <HandSkeleton pose={step.pose} size={54} color={step.color} animated={false} />
                </div>
                <div className="glass glow-hover mb-6 flex-1 rounded-2xl p-6">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold tracking-widest" style={{ color: step.color }}>
                      STEP {i + 1}
                    </span>
                    <span className="h-px flex-1 bg-white/10" aria-hidden="true" />
                  </div>
                  <h2 className="mt-2 text-xl font-bold text-white">{step.title}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-slate-400">{step.text}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10 text-center">
          <div className="glass rounded-3xl p-8">
            <h2 className="text-xl font-bold text-white">Watch it happen</h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-slate-400">
              The translator shows the live hand skeleton, the detected sign, the
              confidence, and the sentence being built — in real time.
            </p>
            <div className="mt-6">
              <Link to="/translator" className="btn-cta">
                <span aria-hidden="true">🖐️</span> Open the Translator
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  )
}
