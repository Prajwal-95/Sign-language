import { useCallback, useEffect, useState } from 'react'
import { useWebcam, type CameraStatus } from '../hooks/useWebcam'
import { useSignRecognition } from '../hooks/useSignRecognition'
import { checkBackendHealth } from '../services/api'
import StatusIndicator from '../components/StatusIndicator'
import HandOverlay from '../components/HandOverlay'
import SampleCollector from '../components/SampleCollector'
import HandSkeleton from '../components/HandSkeleton'
import SigningHand, { type SignPose } from '../components/SigningHand'
import Waveform from '../components/Waveform'
import Reveal from '../components/Reveal'

const PANEL_CLASS = 'glass rounded-2xl p-4'

function cameraLabel(status: CameraStatus): string {
  switch (status) {
    case 'idle':
      return 'Camera off'
    case 'requesting':
      return 'Requesting permission…'
    case 'active':
      return 'Camera active'
    case 'denied':
      return 'Permission denied'
    case 'unavailable':
      return 'No camera found'
    default:
      return 'Camera error'
  }
}

function modelLabel(ready: boolean): string {
  return ready ? 'Model loaded' : 'Model idle'
}

function socketLabel(s: string): string {
  switch (s) {
    case 'open':
      return 'Backend connected'
    case 'connecting':
      return 'Connecting…'
    case 'error':
      return 'Backend error'
    case 'closed':
      return 'Backend disconnected'
    default:
      return 'Backend idle'
  }
}

function recLabel(s: string): string {
  switch (s) {
    case 'running':
      return 'Recognizing'
    case 'paused':
      return 'Paused'
    case 'loading-model':
      return 'Loading model…'
    case 'error':
      return 'Recognition error'
    default:
      return 'Recognition off'
  }
}

const BANNER =
  'mt-4 rounded-xl border p-4 text-sm backdrop-blur'
const BANNER_WARN = 'border-amber-400/30 bg-amber-400/10 text-amber-200'
const BANNER_ERR = 'border-red-400/30 bg-red-400/10 text-red-200'

export default function Translator() {
  const { videoRef, status: camStatus, error: camError, start: startCam, stop: stopCam } = useWebcam({
    width: 640,
    height: 480,
  })

  const [backend, setBackend] = useState<'checking' | 'online' | 'offline'>('checking')
  const [backendModelLoaded, setBackendModelLoaded] = useState(false)
  const [numClasses, setNumClasses] = useState<number | null>(null)

  const rec = useSignRecognition({
    apiBase: import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000',
    videoRef,
  })

  // Check backend + model availability once.
  useEffect(() => {
    let cancelled = false
    checkBackendHealth().then((res) => {
      if (cancelled) return
      setBackend(res ? 'online' : 'offline')
      setBackendModelLoaded(Boolean(res?.model_loaded))
      if (res?.num_classes) setNumClasses(res.num_classes)
    })
    return () => {
      cancelled = true
    }
  }, [])

  // Keep the backend/model banner live (re-check when connection changes).
  useEffect(() => {
    if (rec.socketStatus === 'open' && backend !== 'online') setBackend('online')
  }, [rec.socketStatus, backend])

  const startTranslation = useCallback(async () => {
    if (camStatus !== 'active') {
      await startCam()
    }
    rec.start()
  }, [camStatus, startCam, rec])

  const stopTranslation = useCallback(() => {
    rec.stop()
    stopCam()
  }, [rec, stopCam])

  const isRecognizing = rec.status === 'running' || rec.status === 'paused'
  const canSpeak = rec.sentence.trim().length > 0

  return (
    <div className="relative mx-auto max-w-6xl px-4 py-8">
      {/* ambient stage */}
      <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden="true">
        <div className="aurora anim-drift" style={{ width: 420, height: 420, left: '-10%', top: '-10%', background: 'radial-gradient(circle, rgba(139,92,246,0.14), transparent 70%)' }} />
        <div className="aurora anim-drift" style={{ width: 380, height: 380, right: '-8%', top: '20%', background: 'radial-gradient(circle, rgba(34,211,238,0.12), transparent 70%)', animationDelay: '5s' }} />
      </div>

      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <span className="kicker">Live translator</span>
            <h1 className="mt-2 text-3xl font-extrabold text-white sm:text-4xl">
              ISL <span className="text-gradient">→</span> Speech
            </h1>
            <p className="mt-1 text-slate-400">
              Perform a sign — the app reads your hand live and speaks the result.
            </p>
          </div>
          <HandSkeleton pose="peace" size={56} color="#22d3ee" />
        </div>
      </Reveal>

      {backend === 'offline' && (
        <div role="status" className={`${BANNER} ${BANNER_WARN}`}>
          <strong>Backend offline.</strong> Start it with <code>cd backend</code> then{' '}
          <code>.\run.bat</code>. The camera preview below still works.
        </div>
      )}

      {backend === 'online' && !backendModelLoaded && (
        <div role="status" className={`${BANNER} ${BANNER_WARN}`}>
          <strong>No trained model on the backend.</strong> Run{' '}
          <code>python scripts\train_model.py</code> to train one.
        </div>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Camera panel */}
        <section aria-label="Camera feed" className={`${PANEL_CLASS} lg:col-span-2`}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-semibold text-white">Camera Feed</h2>
            <div className="flex flex-wrap items-center gap-2">
              <StatusIndicator status={camStatus} label={cameraLabel(camStatus)} />
              <StatusIndicator status={rec.modelReady ? 'active' : 'idle'} label={modelLabel(rec.modelReady)} />
            </div>
          </div>

          <div className="viewfinder relative mt-4 aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-black">
            {camStatus === 'active' ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="video-mirror h-full w-full object-cover"
                />
                <HandOverlay
                  videoRef={videoRef}
                  landmarksRef={rec.landmarksRef}
                  active={rec.status === 'running'}
                />
                {/* scanline shimmer */}
                <div
                  className="pointer-events-none absolute inset-0 opacity-[0.05]"
                  style={{
                    backgroundImage:
                      'repeating-linear-gradient(0deg, rgba(255,255,255,0.6) 0 1px, transparent 1px 3px)',
                    animation: 'scanline 9s linear infinite',
                  }}
                  aria-hidden="true"
                />
              </>
            ) : (
              <div className="flex h-full flex-col items-center justify-center gap-3 text-slate-500">
                <HandSkeleton pose="open" size={110} color="#22d3ee" animated={false} className="opacity-60" />
                <p className="text-sm">Camera is off — start translation to begin.</p>
              </div>
            )}
          </div>

          {camError && (
            <div role="alert" className={`${BANNER} ${BANNER_ERR}`}>
              <strong className="block">Camera error:</strong>
              {camError.message}
            </div>
          )}

          {rec.error && (
            <div role="alert" className={`${BANNER} ${BANNER_ERR}`}>
              <strong className="block">Recognition error:</strong>
              {rec.error}
            </div>
          )}

          <div className="mt-4 flex flex-wrap gap-3">
            {!isRecognizing ? (
              <button
                onClick={() => void startTranslation()}
                className="btn-cta"
              >
                <span aria-hidden="true">🎥</span> Start Translation
              </button>
            ) : (
              <button
                onClick={stopTranslation}
                className="btn-ghost !border-red-400/40 !text-red-200 hover:!border-red-300 hover:!bg-red-400/10"
              >
                Stop Translation
              </button>
            )}

            {isRecognizing && (
              <button
                onClick={rec.status === 'running' ? rec.pause : rec.resume}
                className="btn-ghost"
              >
                {rec.status === 'running' ? 'Pause' : 'Resume'}
              </button>
            )}
          </div>

          {camStatus === 'active' && (
            <p className="mt-3 text-xs text-slate-500" role="status">
              ⦿ Camera active. Only hand landmark coordinates are sent to the backend —{' '}
              <strong>video frames never leave your device</strong>.
            </p>
          )}
        </section>

        {/* Right column */}
        <div className="flex flex-col gap-6">
          <section aria-label="Detected sign" className={PANEL_CLASS}>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">Detected Sign</h2>
              <SigningHand
                sequence={(['open', 'wave1', 'open', 'wave2'] as SignPose[])}
                segmentMs={900}
                size={42}
                color="#22d3ee"
                className="opacity-80"
              />
            </div>
            <div className="relative mt-3 overflow-hidden rounded-xl border border-white/8 bg-black/40 p-4 text-center">
              {rec.detectedSign && (
                <span key={`r-${rec.detectedSign}-${rec.confidence}`} className="shock-ring" aria-hidden="true" />
              )}
              <p
                key={rec.detectedSign ?? 'none'}
                className="sign-moment relative text-5xl font-extrabold tracking-wide text-gradient"
              >
                {rec.detectedSign ?? '—'}
              </p>
            </div>
            <div className="mt-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Confidence</span>
                <span>{rec.confidence}%</span>
              </div>
              <div
                role="progressbar"
                aria-valuenow={rec.confidence}
                aria-valuemin={0}
                aria-valuemax={100}
                className="mt-1 h-2 w-full overflow-hidden rounded-full bg-white/10"
              >
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${rec.confidence}%`,
                    background: 'linear-gradient(90deg, #22d3ee, #8b5cf6, #e879f9)',
                    boxShadow: '0 0 14px rgba(139,92,246,0.7)',
                  }}
                />
              </div>
            </div>
            <p className="mt-2 text-xs text-slate-500">
              A sign is accepted only after you complete it (hand down).
            </p>
          </section>

          <section aria-label="Translation" className={PANEL_CLASS}>
            <h2 className="text-lg font-semibold text-white">Translation</h2>
            <p
              className="mt-3 min-h-[4.5rem] rounded-xl border border-white/8 bg-black/40 p-3 text-lg font-medium tracking-wide text-white"
              aria-live="polite"
            >
              {rec.sentence || (
                <span className="italic text-slate-500">Raise your hand and sign to begin…</span>
              )}
            </p>
            <div className="mt-3">
              <Waveform bars={22} height={22} color={rec.sentence ? '#34d399' : '#334155'} idle={!rec.sentence} />
            </div>
            <p className="mt-2 text-xs text-slate-500">
              Each recognized sign adds a <strong>word</strong> automatically.
              Raise your hand to sign, lower it between words.
            </p>
          </section>

          <section aria-label="Controls" className={PANEL_CLASS}>
            <h2 className="text-lg font-semibold text-white">Controls</h2>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
              <button
                onClick={rec.addSpace}
                disabled={!isRecognizing}
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-35"
              >
                Space
              </button>
              <button
                onClick={rec.undo}
                disabled={!rec.sentence}
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-35"
              >
                Undo
              </button>
              <button
                onClick={rec.clear}
                disabled={!rec.sentence}
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-35"
              >
                Clear
              </button>
              <button
                onClick={rec.speakAll}
                disabled={!canSpeak}
                className="rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 px-4 py-2 text-sm font-bold text-emerald-950 hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-35"
              >
                🔊 Speak
              </button>
              <button
                onClick={rec.stopSpeechAll}
                disabled={!rec.ttsAvailable}
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-35"
              >
                Stop Speech
              </button>
              <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200">
                <input
                  type="checkbox"
                  checked={rec.autoSpeak}
                  onChange={(e) => {
                    const on = e.target.checked
                    rec.setAutoSpeak(on)
                    // Speak immediately when switched on (user gesture),
                    // then auto-speak keeps reading each new word.
                    if (on && rec.sentence.trim()) rec.speakAll()
                  }}
                  className="h-4 w-4 accent-emerald-400"
                />
                Auto-speak
              </label>
            </div>
            {!rec.ttsAvailable && (
              <p className="mt-2 text-xs text-amber-300/80">
                Speech is not supported in this browser. Text output still works.
              </p>
            )}
          </section>
        </div>
      </div>

      {/* Calibration: record YOUR hand into the training data */}
      <div className="mt-6">
        <SampleCollector
          collectHandsRef={rec.collectHandsRef}
          recognizing={rec.status === 'running'}
        />
      </div>

      {/* Bottom status bar */}
      <div className="mt-6 flex flex-wrap items-center gap-2 text-sm">
        <StatusIndicator status={backend === 'online' ? 'active' : backend === 'offline' ? 'error' : 'requesting'} label={backend === 'online' ? `Backend online${numClasses ? ` · ${numClasses} signs` : ''}` : backend === 'offline' ? 'Backend offline' : 'Checking backend…'} />
        <StatusIndicator status={socketLabel(rec.socketStatus) === 'Backend connected' ? 'active' : rec.socketStatus === 'error' ? 'error' : 'idle'} label={socketLabel(rec.socketStatus)} />
        <StatusIndicator status={rec.status === 'running' ? 'active' : rec.status === 'paused' ? 'requesting' : 'idle'} label={recLabel(rec.status)} />
      </div>
    </div>
  )
}
