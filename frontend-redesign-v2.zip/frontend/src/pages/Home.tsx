import { Link } from 'react-router-dom'
import HeroScene from '../components/HeroScene'
import HandSkeleton from '../components/HandSkeleton'
import GesturePath from '../components/GesturePath'
import Waveform from '../components/Waveform'
import Reveal from '../components/Reveal'

const SIGNS = [
  { word: 'HELLO', pose: 'open' as const, tag: 'greeting' },
  { word: 'THANK YOU', pose: 'thumb' as const, tag: 'greeting' },
  { word: 'GOOD MORNING', pose: 'peace' as const, tag: 'greeting' },
  { word: 'MAYBE', pose: 'point' as const, tag: 'daily' },
  { word: 'DRINK', pose: 'fist' as const, tag: 'action' },
  { word: 'JUMP', pose: 'pinky' as const, tag: 'action' },
  { word: 'ELEPHANT', pose: 'point' as const, tag: 'animal' },
  { word: 'TIGER', pose: 'fist' as const, tag: 'animal' },
]

const PIPELINE = [
  { icon: '📷', title: 'Camera', text: 'Your webcam watches your hands — nothing is recorded or uploaded.' },
  { icon: '✋', title: '21 Landmarks', text: 'MediaPipe extracts a glowing hand skeleton — 21 points, both hands.' },
  { icon: '🧠', title: 'GRU Network', text: 'A temporal neural network reads the motion sequence in real time.' },
  { icon: '🔊', title: 'Speech', text: 'The recognized sign becomes a word in your sentence — spoken aloud.' },
]

const STATS = [
  { value: '98.86%', label: 'test accuracy' },
  { value: '20', label: 'daily ISL signs' },
  { value: '128', label: 'features per frame' },
  { value: '< 2s', label: 'per sign, live' },
]

export default function Home() {
  return (
    <div className="relative">
      <HeroScene />

      {/* ---- Signs showcase ---- */}
      <section className="relative mx-auto max-w-6xl px-4 py-20">
        <Reveal className="text-center">
          <span className="kicker">The vocabulary</span>
          <h2 className="mt-3 text-3xl font-bold text-white sm:text-4xl">
            Twenty signs. <span className="text-gradient">One gesture at a time.</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-slate-400">
            Common daily words — greetings, actions and more — each a distinct motion
            the model has learned from the official Indian Sign Language channel.
          </p>
        </Reveal>

        <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {SIGNS.map((s, i) => (
            <Reveal key={s.word} delay={i * 60}>
              <div className="glass glow-hover group flex flex-col items-center rounded-2xl p-6 text-center">
                <HandSkeleton
                  pose={s.pose}
                  size={92}
                  color={i % 2 ? '#8b5cf6' : '#22d3ee'}
                  className="transition-transform duration-500 group-hover:scale-110"
                />
                <span className="mt-4 text-xs font-semibold uppercase tracking-widest text-cyan-300/70">
                  {s.tag}
                </span>
                <h3 className="mt-1 text-lg font-bold text-white">{s.word}</h3>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-8 text-center">
          <Link to="/translator" className="btn-ghost">
            See all 20 signs in the translator →
          </Link>
        </Reveal>
      </section>

      {/* ---- Pipeline ---- */}
      <section className="relative overflow-hidden border-y border-white/8 bg-[#060a14] py-20">
        <div className="pointer-events-none absolute inset-0" aria-hidden="true">
          <div className="aurora" style={{ width: 460, height: 460, left: '50%', top: '-30%', transform: 'translateX(-50%)', background: 'radial-gradient(circle, rgba(34,211,238,0.16), transparent 70%)' }} />
        </div>
        <div className="relative mx-auto max-w-6xl px-4">
          <Reveal className="text-center">
            <span className="kicker">The pipeline</span>
            <h2 className="mt-3 text-3xl font-bold text-white sm:text-4xl">
              From gesture to <span className="text-gradient-amber">voice</span>
            </h2>
          </Reveal>

          <div className="mt-14 grid gap-10 md:grid-cols-4 md:gap-6">
            {PIPELINE.map((step, i) => (
              <Reveal key={step.title} delay={i * 110} className="relative">
                {i < PIPELINE.length - 1 && (
                  <div className="absolute -right-4 top-8 hidden w-8 md:block" aria-hidden="true">
                    <GesturePath horizontal color={i % 2 ? '#e879f9' : '#22d3ee'} />
                  </div>
                )}
                <div className="glass glow-hover h-full rounded-2xl p-6 text-center">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 text-2xl ring-1 ring-white/10 anim-glow">
                    <span aria-hidden="true">{step.icon}</span>
                  </div>
                  <div className="mt-3 text-xs font-bold tracking-widest text-violet-300/80">
                    STEP {i + 1}
                  </div>
                  <h3 className="mt-1 text-lg font-bold text-white">{step.title}</h3>
                  <p className="mt-2 text-sm text-slate-400">{step.text}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-14 text-center">
            <Waveform bars={40} height={34} color="#fbbf24" />
          </Reveal>
        </div>
      </section>

      {/* ---- Stats ---- */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="glass-strong grid grid-cols-2 gap-6 rounded-3xl p-8 sm:grid-cols-4">
          {STATS.map((s, i) => (
            <Reveal key={s.label} delay={i * 70} className="text-center">
              <div className="text-3xl font-extrabold text-gradient sm:text-4xl">{s.value}</div>
              <div className="mt-1 text-xs uppercase tracking-widest text-slate-400">{s.label}</div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---- CTA ---- */}
      <section className="relative mx-auto max-w-5xl px-4 pb-8">
        <Reveal>
          <div className="glass relative overflow-hidden rounded-3xl p-10 text-center sm:p-14">
            <div className="pointer-events-none absolute inset-0" aria-hidden="true">
              <div className="aurora anim-drift" style={{ width: 300, height: 300, left: '-6%', bottom: '-40%', background: 'radial-gradient(circle, rgba(139,92,246,0.3), transparent 70%)' }} />
              <div className="aurora anim-drift" style={{ width: 280, height: 280, right: '-6%', top: '-45%', background: 'radial-gradient(circle, rgba(34,211,238,0.28), transparent 70%)', animationDelay: '7s' }} />
            </div>
            <div className="relative">
              <div className="mx-auto w-fit anim-float">
                <HandSkeleton pose="peace" size={84} color="#22d3ee" />
              </div>
              <h2 className="mt-6 text-3xl font-bold text-white sm:text-4xl">
                Ready to <span className="shimmer">try it yourself?</span>
              </h2>
              <p className="mx-auto mt-4 max-w-md text-slate-400">
                Turn on your camera, raise your hand, and watch your signs become words —
                and your words become voice.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-4">
                <Link to="/translator" className="btn-cta">
                  <span aria-hidden="true">🖐️</span> Open the Translator
                </Link>
                <Link to="/about" className="btn-ghost">About the project</Link>
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  )
}
