import { Link } from 'react-router-dom'
import HandSkeleton from '../components/HandSkeleton'
import Reveal from '../components/Reveal'
import Waveform from '../components/Waveform'

const HIGHLIGHTS = [
  { title: 'Real-time & local', text: 'MediaPipe hand tracking runs in your browser; only compact landmark coordinates travel to the backend. Video never leaves your device.' },
  { title: 'Temporal AI', text: 'A GRU neural network reads sequences of two-hand landmark features (128 per frame) to recognize the motion of a sign.' },
  { title: 'Honest, evaluated', text: '98.86% test accuracy on 20 daily ISL signs — real numbers from a held-out test set, saved with confusion matrices.' },
  { title: 'Built to grow', text: 'The vocabulary lives in one file. Add signs, record samples, retrain — the architecture stays the same.' },
]

const STACK = [
  'React + TypeScript', 'Tailwind CSS', 'FastAPI', 'MediaPipe', 'PyTorch', 'GRU', 'WebSocket', 'Web Speech API',
]

export default function About() {
  return (
    <div className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="aurora anim-drift" style={{ width: 420, height: 420, right: '-8%', top: '-6%', background: 'radial-gradient(circle, rgba(139,92,246,0.2), transparent 70%)' }} />
        <div className="grid-lines" />
      </div>

      <div className="relative mx-auto max-w-4xl px-4 py-16">
        <Reveal className="text-center">
          <span className="kicker">About the project</span>
          <h1 className="mt-3 text-4xl font-extrabold text-white sm:text-5xl">
            A bridge of <span className="text-gradient">hands and voice</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-slate-400">
            A final-year CSE major project: Real-Time Indian Sign Language (ISL) to
            Speech Conversion using Computer Vision and Machine Learning. It turns the
            motion of your hands into words you can hear.
          </p>
          <div className="mt-8 flex justify-center">
            <Waveform bars={32} height={30} color="#22d3ee" />
          </div>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2">
          {HIGHLIGHTS.map((h, i) => (
            <Reveal key={h.title} delay={i * 80}>
              <div className="glass glow-hover h-full rounded-2xl p-6">
                <div className="w-fit">
                  <HandSkeleton pose={(['open', 'peace', 'point', 'thumb'] as const)[i]} size={52} color={['#22d3ee', '#8b5cf6', '#e879f9', '#34d399'][i]} animated={false} />
                </div>
                <h3 className="mt-4 text-lg font-bold text-white">{h.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{h.text}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12">
          <div className="glass rounded-3xl p-8">
            <h2 className="text-xl font-bold text-white">Technology stack</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {STACK.map((t) => (
                <span key={t} className="chip">{t}</span>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal className="mt-8">
          <div className="rounded-3xl border border-amber-400/20 bg-amber-400/5 p-8">
            <h2 className="text-lg font-bold text-amber-200">Honest scope</h2>
            <p className="mt-3 text-sm leading-relaxed text-amber-100/80">
              This system recognizes a <strong>defined vocabulary of 20 ISL word signs</strong> —
              it is not a full ISL translator. Indian Sign Language is a complete language with
              its own grammar and thousands of signs; continuous translation is future work.
              All reported accuracy figures come from real training runs, and all training data
              is drawn from publicly available ISL datasets (credited in the documentation).
            </p>
          </div>
        </Reveal>

        <Reveal className="mt-10 text-center">
          <Link to="/translator" className="btn-cta">
            <span aria-hidden="true">🖐️</span> Try it now
          </Link>
        </Reveal>
      </div>
    </div>
  )
}
