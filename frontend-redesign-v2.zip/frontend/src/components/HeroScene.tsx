import { Link } from 'react-router-dom'
import SigningHand, { type SignPose } from './SigningHand'
import PointerHand from './PointerHand'
import Waveform from './Waveform'

/**
 * HeroScene — cinematic opening: an aurora stage where multiple hands
 * actually SIGN (morphing poses with motion trails), a cursor-following
 * signing hand, shimmering headline, live waveform, glowing CTAs.
 */
export default function HeroScene() {
  const seqA: SignPose[] = ['open', 'wave1', 'open', 'wave2']
  const seqB: SignPose[] = ['peace', 'point', 'peace', 'point']
  const seqC: SignPose[] = ['fist', 'pinky', 'fist', 'thumb']

  return (
    <section className="relative overflow-hidden">
      {/* ---- stage background ---- */}
      <div className="absolute inset-0" aria-hidden="true">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse 70% 55% at 50% -10%, rgba(139,92,246,0.22), transparent 60%),' +
              'radial-gradient(ellipse 50% 45% at 85% 20%, rgba(34,211,238,0.16), transparent 60%),' +
              'radial-gradient(ellipse 55% 50% at 12% 30%, rgba(232,121,249,0.12), transparent 60%)',
          }}
        />
        <div className="aurora anim-drift" style={{ width: 420, height: 420, left: '-8%', top: '10%', background: 'radial-gradient(circle, rgba(139,92,246,0.35), transparent 70%)' }} />
        <div className="aurora anim-drift" style={{ width: 380, height: 380, right: '-6%', top: '4%', background: 'radial-gradient(circle, rgba(34,211,238,0.30), transparent 70%)', animationDelay: '6s' }} />
        <div className="grid-lines" />
        <div className="vignette" />
      </div>

      {/* ---- floating SIGNING hands ---- */}
      <div className="pointer-events-none absolute inset-0 hidden lg:block" aria-hidden="true">
        <div className="absolute left-[4%] top-[14%] opacity-80">
          <SigningHand sequence={seqA} segmentMs={1500} size={220} color="#22d3ee" />
        </div>
        <div className="absolute right-[5%] top-[20%] opacity-70">
          <SigningHand sequence={seqB} segmentMs={1900} size={180} color="#8b5cf6" mirror />
        </div>
        <div className="absolute bottom-[10%] left-[15%] opacity-50">
          <SigningHand sequence={seqC} segmentMs={1200} size={100} color="#e879f9" />
        </div>
        <div className="absolute bottom-[14%] right-[17%] opacity-50">
          <SigningHand sequence={seqA} segmentMs={1700} size={92} color="#34d399" mirror />
        </div>
      </div>

      {/* ---- cursor-following signing hand (desktop) ---- */}
      <PointerHand />

      {/* ---- content ---- */}
      <div className="relative mx-auto flex max-w-5xl flex-col items-center px-4 pb-24 pt-24 text-center sm:pt-32">
        <span className="chip anim-glow" style={{ animationDelay: '0.2s' }}>
          <span className="inline-block h-2 w-2 rounded-full bg-emerald-400" aria-hidden="true" />
          REAL-TIME · PRIVACY-FIRST · 20 ISL SIGNS
        </span>

        <h1 className="mt-8 text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
          <span className="shimmer">Speak with</span>
          <br />
          <span className="text-gradient">your hands.</span>
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-relaxed text-[#b7c2da] sm:text-lg">
          Indian Sign Language, translated in real time. Your webcam watches your
          hands, a neural network reads the motion, and every sign becomes a word —
          spoken aloud.
        </p>

        <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
          <Link to="/translator" className="btn-cta">
            <span aria-hidden="true">🖐️</span> Start Translating
          </Link>
          <Link to="/how-it-works" className="btn-ghost">
            See how it works
          </Link>
        </div>

        <div className="mt-12 w-full max-w-md opacity-90">
          <Waveform bars={36} height={40} color="#22d3ee" />
        </div>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <span className="chip"><b>98.86%</b> test accuracy</span>
          <span className="chip"><b>20</b> daily signs</span>
          <span className="chip"><b>128</b> features / frame</span>
          <span className="chip"><b>&lt;2s</b> per sign</span>
        </div>
      </div>

      {/* scroll cue */}
      <div className="relative flex justify-center pb-8" aria-hidden="true">
        <div className="flex h-10 w-6 items-start justify-center rounded-full border border-white/20 p-1.5">
          <span className="h-2 w-1 rounded-full bg-cyan-300 anim-float" style={{ animationDuration: '1.6s' }} />
        </div>
      </div>
    </section>
  )
}
