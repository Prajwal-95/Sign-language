import HandSkeleton from './HandSkeleton'

export default function PlaceholderPage({ title, note }: { title: string; note: string }) {
  return (
    <div className="relative mx-auto max-w-3xl px-4 py-20 text-center">
      <div className="pointer-events-none absolute inset-0 flex justify-center opacity-[0.07]" aria-hidden="true">
        <HandSkeleton pose="fist" size={420} color="#8b5cf6" animated={false} />
      </div>
      <div className="glass relative rounded-3xl p-10">
        <div className="mx-auto w-fit">
          <HandSkeleton pose="thumb" size={72} color="#22d3ee" />
        </div>
        <h1 className="mt-5 text-2xl font-bold text-white">{title}</h1>
        <p className="mt-3 text-slate-400">{note}</p>
        <span className="chip mt-6">Coming soon</span>
      </div>
    </div>
  )
}
