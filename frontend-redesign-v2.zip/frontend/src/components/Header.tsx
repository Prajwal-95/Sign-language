import { NavLink } from 'react-router-dom'
import HandSkeleton from './HandSkeleton'

const links = [
  { to: '/', label: 'Home' },
  { to: '/translator', label: 'Translator' },
  { to: '/how-it-works', label: 'How It Works' },
  { to: '/about', label: 'About' },
  { to: '/dataset', label: 'Dataset' },
  { to: '/settings', label: 'Settings' },
]

export default function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-white/8 bg-[#04060d]/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-3">
        <NavLink to="/" className="group flex items-center gap-2.5">
          <span className="transition-transform duration-500 group-hover:rotate-6">
            <HandSkeleton pose="open" size={34} color="#22d3ee" animated={false} />
          </span>
          <span className="text-lg font-bold tracking-tight text-white">
            ISL<span className="text-gradient">→</span>Speech
          </span>
        </NavLink>

        <nav aria-label="Main navigation" className="flex flex-wrap items-center gap-1">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `rounded-full px-3.5 py-1.5 text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-white shadow-[0_0_18px_-6px_rgba(34,211,238,0.6)] ring-1 ring-white/15'
                    : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  )
}
