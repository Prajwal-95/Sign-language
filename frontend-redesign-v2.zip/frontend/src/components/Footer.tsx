import HandSkeleton from './HandSkeleton'
import Waveform from './Waveform'

export default function Footer() {
  return (
    <footer className="relative mt-24 border-t border-white/8 bg-[#04060d]">
      <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-center opacity-40" aria-hidden="true">
        <Waveform bars={48} height={26} color="#8b5cf6" idle />
      </div>
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 py-10 text-center">
        <HandSkeleton pose="open" size={40} color="#22d3ee" animated={false} />
        <div className="flex flex-wrap items-center justify-center gap-2 text-sm text-slate-400">
          <span>Real-Time ISL → Speech Conversion</span>
          <span className="text-slate-600">·</span>
          <span>Final Year CSE Major Project</span>
          <span className="text-slate-600">·</span>
          <span className="chip">GRU model · 98.86% test accuracy</span>
        </div>
        <p className="max-w-xl text-xs leading-relaxed text-slate-500">
          Recognizes a defined vocabulary of 20 Indian Sign Language word signs. This is an
          academic project — it is not a full ISL translator, and video frames never leave
          your device.
        </p>
      </div>
    </footer>
  )
}
