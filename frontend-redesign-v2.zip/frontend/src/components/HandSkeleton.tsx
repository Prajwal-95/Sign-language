import { useMemo } from 'react'

/**
 * HandSkeleton — the signature motif of the site.
 *
 * It draws the SAME 21 MediaPipe hand landmarks your pipeline extracts,
 * as a glowing node-and-edge network. Poses bend the fingertips so the
 * illustration can "sign" — open palm, peace, fist, point, pinky, thumb.
 */

type Pose = 'open' | 'peace' | 'fist' | 'point' | 'pinky' | 'thumb'

// Base 21 landmarks in a 0..100 space (x, y) — MediaPipe hand layout.
const BASE: [number, number][] = [
  [50, 80], [38, 70], [30, 58], [27, 47], [26, 37], // 0 wrist, 1-4 thumb
  [48, 48], [50, 33], [51, 23], [52, 16],           // 5-8 index
  [58, 46], [61, 29], [62, 18], [63, 10],           // 9-12 middle
  [67, 48], [71, 32], [72, 23], [73, 16],           // 13-16 ring
  [75, 52], [80, 40], [81, 32], [82, 26],           // 17-20 pinky
]

const CONNECTIONS: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [0, 9], [9, 10], [10, 11], [11, 12],
  [0, 13], [13, 14], [14, 15], [15, 16],
  [0, 17], [17, 18], [18, 19], [19, 20],
  [5, 9], [9, 13], [13, 17],
]

// Finger tips: thumb 4, index 8, middle 12, ring 16, pinky 20
const TIPS: Record<string, number> = { thumb: 4, index: 8, middle: 12, ring: 16, pinky: 20 }

function posedLandmarks(pose: Pose): [number, number][] {
  const pts = BASE.map((p) => [...p] as [number, number])
  const up = (i: number, lift: number) => { pts[i][1] -= lift }   // raise tip (y up = smaller)
  const down = (i: number, drop: number) => { pts[i][1] += drop } // fold tip toward palm
  switch (pose) {
    case 'peace':
      up(TIPS.index, 26); up(TIPS.middle, 24);
      down(TIPS.ring, 18); down(TIPS.pinky, 22); down(TIPS.thumb, 12);
      break
    case 'fist':
      down(TIPS.index, 26); down(TIPS.middle, 26); down(TIPS.ring, 24); down(TIPS.pinky, 22); down(TIPS.thumb, 12);
      break
    case 'point':
      up(TIPS.index, 30);
      down(TIPS.middle, 22); down(TIPS.ring, 24); down(TIPS.pinky, 26); down(TIPS.thumb, 12);
      break
    case 'pinky':
      up(TIPS.pinky, 26);
      down(TIPS.index, 22); down(TIPS.middle, 24); down(TIPS.ring, 22); down(TIPS.thumb, 12);
      break
    case 'thumb':
      up(TIPS.thumb, 20); pts[TIPS.thumb][0] -= 4;
      down(TIPS.index, 16); down(TIPS.middle, 20); down(TIPS.ring, 22); down(TIPS.pinky, 26);
      break
    default: // open
      break
  }
  return pts
}

interface Props {
  pose?: Pose
  size?: number
  color?: string
  className?: string
  mirror?: boolean
  animated?: boolean
  dotSize?: number
}

export default function HandSkeleton({
  pose = 'open',
  size = 120,
  color = '#22d3ee',
  className = '',
  mirror = false,
  animated = true,
  dotSize = 2.1,
}: Props) {
  const pts = useMemo(() => posedLandmarks(pose), [pose])

  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={`hs-wrap ${animated ? 'anim-glow' : ''} ${className}`}
      style={{ color, transform: mirror ? 'scaleX(-1)' : undefined }}
      aria-hidden="true"
    >
      <g stroke="currentColor" fill="none">
        {CONNECTIONS.map(([a, b], i) => (
          <line
            key={i}
            x1={pts[a][0]} y1={pts[a][1]}
            x2={pts[b][0]} y2={pts[b][1]}
            className="hs-line"
          />
        ))}
      </g>
      {pts.map(([x, y], i) => (
        <circle
          key={i}
          cx={x} cy={y}
          r={dotSize}
          className="hs-dot"
          style={animated ? { animationDelay: `${(i % 7) * 0.18}s` } : undefined}
        />
      ))}
      {/* soft bloom behind the wrist */}
      <circle cx={pts[0][0]} cy={pts[0][1]} r={7} fill="currentColor" opacity={0.12} />
    </svg>
  )
}
