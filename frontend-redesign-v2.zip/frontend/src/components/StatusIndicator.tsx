const PALETTE: Record<string, string> = {
  active: 'bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)]',
  requesting: 'bg-amber-400 animate-pulse',
  idle: 'bg-slate-500',
  denied: 'bg-red-400',
  unavailable: 'bg-red-400',
  error: 'bg-red-400',
}

export default function StatusIndicator({ status, label }: { status: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300 backdrop-blur">
      <span aria-hidden="true" className={`h-2 w-2 rounded-full ${PALETTE[status] ?? 'bg-slate-500'}`} />
      {label}
    </span>
  )
}
