import { useCallback, useEffect, useRef, useState } from 'react'
import { fetchVocab, recordSample } from '../services/api'

interface Props {
  collectHandsRef: React.MutableRefObject<((hands: unknown[]) => void) | null>
  recognizing: boolean // recognition loop running (needed to capture frames)
}

const TARGET_FRAMES = 40 // ~1.3-2s of frames per sample
const MIN_FRAMES = 14

/**
 * "Record MY hand" tool: while recognition is running, this captures raw
 * hand landmarks from the user's own webcam for a chosen sign and POSTs
 * them to the backend, which saves them into dataset/seq/<SIGN>/user_*.npz.
 * Re-running scripts/train_lstm.py then trains the model on YOUR hand too —
 * fixing the domain-shift problem (model trained on studio signers failing
 * live).
 */
export default function SampleCollector({ collectHandsRef, recognizing }: Props) {
  const [vocab, setVocab] = useState<string[]>([])
  const [sign, setSign] = useState('')
  const [recording, setRecording] = useState(false)
  const [frames, setFrames] = useState(0)
  const [savedCount, setSavedCount] = useState(0)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)

  const bufferRef = useRef<unknown[][]>([])
  const savedRef = useRef(0)

  // Load the vocabulary once.
  useEffect(() => {
    let cancelled = false
    fetchVocab().then((v) => {
      if (cancelled) return
      setVocab(v)
      setSign(v[0] ?? '')
    })
    return () => {
      cancelled = true
    }
  }, [])

  // Register the collector callback with the recognition loop.
  const handleHands = useCallback((hands: unknown[]) => {
    bufferRef.current.push(hands)
    setFrames(bufferRef.current.length)
    if (bufferRef.current.length >= TARGET_FRAMES) {
      void finishAndSend()
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const finishAndSend = useCallback(async () => {
    const buf = bufferRef.current
    bufferRef.current = []
    setRecording(false)
    if (buf.length < MIN_FRAMES) {
      setMessage({ ok: false, text: `Too few frames (${buf.length}). Keep your hand visible.` })
      return
    }
    if (!sign) {
      setMessage({ ok: false, text: 'Pick a sign first.' })
      return
    }
    try {
      const res = await recordSample(sign, buf.map((hands) => ({ hands })))
      if (!res) {
        setMessage({ ok: false, text: 'Backend did not save the sample.' })
        return
      }
      savedRef.current += 1
      setSavedCount(savedRef.current)
      setMessage({
        ok: true,
        text: `Saved sample #${res.sample_index} for ${res.sign} (${res.frames_used} frames). Keep going — aim for ~10 per sign.`,
      })
    } catch (e) {
      setMessage({ ok: false, text: e instanceof Error ? e.message : String(e) })
    }
  }, [sign])

  const startRecording = () => {
    if (!recognizing) {
      setMessage({ ok: false, text: 'Start Translation first (the camera must be running).' })
      return
    }
    if (recording) return
    bufferRef.current = []
    setFrames(0)
    setMessage(null)
    setRecording(true)
  }

  // Attach the collector callback whenever recording toggles.
  useEffect(() => {
    collectHandsRef.current = recording ? handleHands : null
    return () => {
      collectHandsRef.current = null
    }
  }, [recording, handleHands, collectHandsRef])

  const progress = Math.min(100, Math.round((frames / TARGET_FRAMES) * 100))

  return (
    <div className="glass rounded-2xl p-5">
      <h3 className="text-sm font-bold text-white">
        🎯 Record YOUR hand (fixes live recognition)
      </h3>
      <p className="mt-1 text-xs text-slate-400">
        The model was trained on studio videos. Record your own webcam doing each sign, then
        retrain — the model learns <strong>your</strong> hand in <strong>your</strong> setup.
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <select
          value={sign}
          onChange={(e) => setSign(e.target.value)}
          className="rounded-xl border border-white/15 bg-white/15/5 px-3 py-2 text-sm text-white outline-none"
        >
          {vocab.map((v) => (
            <option key={v} value={v}>
              {v.replace(/_/g, ' ')}
            </option>
          ))}
        </select>

        <button
          onClick={startRecording}
          disabled={recording}
          className="rounded-lg rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-4 py-2 text-sm font-bold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {recording ? 'Recording…' : 'Record sample'}
        </button>

        <span className="text-xs text-slate-300">
          saved: <strong>{savedCount}</strong>
        </span>
      </div>

      {recording && (
        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-slate-300">
            <span>Recording {sign.replace(/_/g, ' ')}… do the sign now, hold it still.</span>
            <span>
              {frames}/{TARGET_FRAMES}
            </span>
          </div>
          <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-white/15">
            <div
              className="h-full rounded-full bg-violet-400 transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {message && (
        <p
          className={`mt-2 text-xs ${message.ok ? 'text-emerald-300' : 'text-red-300'}`}
          role="status"
        >
          {message.text}
        </p>
      )}

      <p className="mt-2 text-[11px] text-slate-400">
        Tip: record ~10 samples per sign, varying distance/angle slightly. Then run{' '}
        <code>python scripts\train_lstm.py --augment --epochs 120 --hidden 256 --lr 5e-4 --patience 40</code>{' '}
        and restart the backend.
      </p>
    </div>
  )
}
