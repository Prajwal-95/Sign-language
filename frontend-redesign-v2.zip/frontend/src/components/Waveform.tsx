import { useMemo } from 'react'

/**
 * Waveform — animated audio bars representing the spoken output.
 * Bars scale vertically in sequence, like a voiceprint.
 */
interface Props {
  bars?: number
  className?: string
  color?: string
  idle?: boolean
  height?: number
}

export default function Waveform({
  bars = 28,
  className = '',
  color = '#22d3ee',
  idle = false,
  height = 44,
}: Props) {
  const items = useMemo(
    () =>
      Array.from({ length: bars }, (_, i) => ({
        h: 30 + ((i * 37) % 55),
        delay: `${(i % 12) * 0.09}s`,
        dur: `${0.9 + ((i * 13) % 5) * 0.12}s`,
      })),
    [bars],
  )

  return (
    <div
      className={`flex items-end gap-[3px] ${idle ? 'wave-idle' : ''} ${className}`}
      style={{ height }}
      aria-hidden="true"
    >
      {items.map((b, i) => (
        <span
          key={i}
          className="wave-bar"
          style={{
            width: Math.max(3, Math.floor(100 / bars)),
            height: `${b.h}%`,
            background: `linear-gradient(180deg, ${color}, ${color}55)`,
            boxShadow: `0 0 8px ${color}66`,
            animationDelay: b.delay,
            animationDuration: b.dur,
          }}
        />
      ))}
    </div>
  )
}
