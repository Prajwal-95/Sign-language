import { useEffect, useRef } from 'react'
import SigningHand, { type SignPose } from './SigningHand'

/**
 * PointerHand — a translucent signing hand that gently follows your cursor
 * across the hero, continuously waving (wave1 → open → wave2). It makes the
 * page feel alive and literally "signs along" with the user's movement.
 * Hidden on touch devices (pointer: coarse).
 */
export default function PointerHand() {
  const ref = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    if (window.matchMedia('(pointer: coarse)').matches) return
    let raf = 0
    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 }
    const cur = { x: target.x, y: target.y }
    const onMove = (e: MouseEvent) => {
      target.x = e.clientX
      target.y = e.clientY
    }
    const tick = () => {
      cur.x += (target.x - cur.x) * 0.16
      cur.y += (target.y - cur.y) * 0.16
      if (ref.current) {
        ref.current.style.transform = `translate(${cur.x}px, ${cur.y}px)`
      }
      raf = requestAnimationFrame(tick)
    }
    window.addEventListener('mousemove', onMove)
    raf = requestAnimationFrame(tick)
    return () => {
      window.removeEventListener('mousemove', onMove)
      cancelAnimationFrame(raf)
    }
  }, [])

  const seq: SignPose[] = ['wave1', 'open', 'wave2', 'open']

  return (
    <div
      ref={ref}
      className="pointer-hand"
      aria-hidden="true"
    >
      <SigningHand sequence={seq} segmentMs={900} size={56} color="#e879f9" trail />
    </div>
  )
}
