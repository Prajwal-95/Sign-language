import { useEffect, useRef } from 'react'

/**
 * SigningHand — the centerpiece animation.
 *
 * Unlike the static HandSkeleton, this hand ACTUALLY SIGNS: it continuously
 * morphs between ISL hand poses (open palm, wave, peace, point, fist,
 * pinky, thumb) with eased interpolation, pulsing landmark dots, and
 * glowing fingertip motion trails — like a hand tracing a sign through the
 * air. It's the visual embodiment of the pipeline.
 */

export type SignPose =
  | 'open'
  | 'wave1'
  | 'wave2'
  | 'peace'
  | 'point'
  | 'fist'
  | 'pinky'
  | 'thumb'

type Pt = [number, number]

// 21 MediaPipe hand landmarks in a 0..100 space.
const BASE: Pt[] = [
  [50, 80], [38, 70], [30, 58], [27, 47], [26, 37], // 0 wrist, 1-4 thumb
  [48, 48], [50, 33], [51, 23], [52, 16],           // 5-8 index
  [58, 46], [61, 29], [62, 18], [63, 10],           // 9-12 middle
  [67, 48], [71, 32], [72, 23], [73, 16],           // 13-16 ring
  [75, 52], [80, 40], [81, 32], [82, 26],           // 17-20 pinky
]

const CONN: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [0, 9], [9, 10], [10, 11], [11, 12],
  [0, 13], [13, 14], [14, 15], [15, 16],
  [0, 17], [17, 18], [18, 19], [19, 20],
  [5, 9], [9, 13], [13, 17],
]

const TIPS = [4, 8, 12, 16, 20]

function posed(pose: SignPose): Pt[] {
  const pts = BASE.map((p) => [p[0], p[1]] as Pt)
  const up = (i: number, d: number) => { pts[i][1] -= d }
  const dn = (i: number, d: number) => { pts[i][1] += d }
  const lx = (i: number, d: number) => { pts[i][0] -= d }
  const rx = (i: number, d: number) => { pts[i][0] += d }
  switch (pose) {
    case 'peace':
      up(8, 26); up(12, 24); dn(16, 18); dn(20, 22); dn(4, 12)
      break
    case 'fist':
      dn(8, 26); dn(12, 26); dn(16, 24); dn(20, 22); dn(4, 12)
      break
    case 'point':
      up(8, 30); dn(12, 22); dn(16, 24); dn(20, 26); dn(4, 12)
      break
    case 'pinky':
      up(20, 26); dn(8, 22); dn(12, 24); dn(16, 22); dn(4, 12)
      break
    case 'thumb':
      up(4, 20); lx(4, 4); dn(8, 16); dn(12, 20); dn(16, 22); dn(20, 26)
      break
    case 'wave1':
      up(8, 18); up(12, 16); up(16, 12); up(20, 8); rx(8, 6); rx(12, 4)
      break
    case 'wave2':
      up(8, 18); up(12, 16); up(16, 12); up(20, 8); lx(8, 6); lx(12, 4)
      break
    default: // open
      break
  }
  return pts
}

function lerp(a: Pt[], b: Pt[], t: number): Pt[] {
  return a.map((p, i) => [p[0] + (b[i][0] - p[0]) * t, p[1] + (b[i][1] - p[1]) * t])
}
const ease = (t: number) => t * t * (3 - 2 * t)

interface Props {
  sequence?: SignPose[]
  segmentMs?: number
  size?: number
  color?: string
  className?: string
  mirror?: boolean
  trail?: boolean
}

const TRAIL_LEN = 8

export default function SigningHand({
  sequence = ['open', 'wave1', 'open', 'wave2'],
  segmentMs = 1300,
  size = 120,
  color = '#22d3ee',
  className = '',
  mirror = false,
  trail = true,
}: Props) {
  const lineRefs = useRef<(SVGLineElement | null)[]>([])
  const dotRefs = useRef<(SVGCircleElement | null)[]>([])
  const trailRefs = useRef<(SVGCircleElement | null)[]>([])

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const poses = sequence.map(posed)
    const total = sequence.length * segmentMs

    const draw = (pts: Pt[], now: number) => {
      CONN.forEach(([a, b], i) => {
        const el = lineRefs.current[i]
        if (!el) return
        el.setAttribute('x1', String(pts[a][0]))
        el.setAttribute('y1', String(pts[a][1]))
        el.setAttribute('x2', String(pts[b][0]))
        el.setAttribute('y2', String(pts[b][1]))
      })
      pts.forEach(([x, y], i) => {
        const el = dotRefs.current[i]
        if (!el) return
        el.setAttribute('cx', String(x))
        el.setAttribute('cy', String(y))
        el.setAttribute('opacity', String(0.45 + 0.55 * Math.abs(Math.sin(now * 0.004 + i * 0.7))))
      })
    }

    // Static first frame for reduced-motion users.
    if (reduce) {
      draw(poses[0], 0)
      return
    }

    // Fingertip trail history (one ring buffer per tip).
    const hist: Pt[][] = TIPS.map(() => Array.from({ length: TRAIL_LEN }, () => [50, 50] as Pt))
    const start = performance.now()
    let raf = 0

    const tick = (now: number) => {
      const phase = ((now - start) % total) / segmentMs
      const seg = Math.floor(phase) % sequence.length
      const t = ease(phase - Math.floor(phase))
      const pts = lerp(poses[seg], poses[(seg + 1) % poses.length], t)
      draw(pts, now)

      if (trail) {
        TIPS.forEach((tip, ti) => {
          hist[ti].pop()
          hist[ti].unshift(pts[tip])
          hist[ti].forEach((p, k) => {
            const el = trailRefs.current[ti * TRAIL_LEN + k]
            if (!el) return
            const fade = 1 - k / TRAIL_LEN
            el.setAttribute('cx', String(p[0]))
            el.setAttribute('cy', String(p[1]))
            el.setAttribute('r', String(1.6 * fade + 0.4))
            el.setAttribute('opacity', String(0.5 * fade))
          })
        })
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [sequence.join(','), segmentMs, trail])

  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={className}
      style={{
        color,
        transform: mirror ? 'scaleX(-1)' : undefined,
        filter: `drop-shadow(0 0 6px ${color})`,
      }}
      aria-hidden="true"
    >
      {/* fingertip trails */}
      <g>
        {TIPS.map((_, ti) =>
          Array.from({ length: TRAIL_LEN }, (_, k) => (
            <circle
              key={`tr-${ti}-${k}`}
              ref={(el) => { trailRefs.current[ti * TRAIL_LEN + k] = el }}
              r={1}
              fill={color}
            />
          )),
        )}
      </g>
      {/* connections */}
      <g stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" opacity="0.55">
        {CONN.map(([a, b], i) => (
          <line
            key={i}
            ref={(el) => { lineRefs.current[i] = el }}
            x1={BASE[a][0]} y1={BASE[a][1]} x2={BASE[b][0]} y2={BASE[b][1]}
          />
        ))}
      </g>
      {/* landmark dots */}
      {BASE.map(([x, y], i) => (
        <circle
          key={i}
          ref={(el) => { dotRefs.current[i] = el }}
          cx={x} cy={y} r={2.2} fill="currentColor"
        />
      ))}
      {/* wrist bloom */}
      <circle cx={BASE[0][0]} cy={BASE[0][1]} r={7} fill="currentColor" opacity={0.12} />
    </svg>
  )
}
