/**
 * GesturePath — a flowing dotted "sign motion" trail drawn in SVG.
 * Represents the movement of a hand performing a sign between two points.
 * Used as a decorative connector in the pipeline / how-it-works sections.
 */
interface Props {
  className?: string
  color?: string
  horizontal?: boolean
}

export default function GesturePath({ className = '', color = '#8b5cf6', horizontal = false }: Props) {
  if (horizontal) {
    return (
      <svg className={className} width="100%" height="24" viewBox="0 0 200 24" fill="none" aria-hidden="true">
        <path
          d="M4 12 H196"
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
          className="gesture-path"
        />
        <circle cx="4" cy="12" r="4" fill={color} className="gesture-dot" />
        <circle cx="196" cy="12" r="3.4" fill={color} className="gesture-dot" style={{ animationDelay: '0.8s' }} />
      </svg>
    )
  }
  return (
    <svg className={className} width="24" height="100%" viewBox="0 0 24 200" fill="none" aria-hidden="true">
      <path
        d="M12 4 V196"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        className="gesture-path"
      />
      <circle cx="12" cy="4" r="4" fill={color} className="gesture-dot" />
      <circle cx="12" cy="196" r="3.4" fill={color} className="gesture-dot" style={{ animationDelay: '0.8s' }} />
    </svg>
  )
}
