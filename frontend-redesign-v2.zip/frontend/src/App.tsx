import { Routes, Route, useLocation } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import Translator from './pages/Translator'
import About from './pages/About'
import HowItWorks from './pages/HowItWorks'
import PlaceholderPage from './components/PlaceholderPage'

/**
 * App shell: header + routed pages + footer.
 */
export default function App() {
  const location = useLocation()
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main key={location.pathname} className="page-enter flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/translator" element={<Translator />} />
          <Route path="/about" element={<About />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route
            path="/dataset"
            element={
              <PlaceholderPage
                title="Dataset & Training"
                note="The model is trained on ISL word signs from the official Indian Sign Language channel (60 videos per word) plus any samples you record with the in-app calibration tool."
              />
            }
          />
          <Route
            path="/settings"
            element={
              <PlaceholderPage
                title="Settings"
                note="High-contrast mode, speech voice and rate, confidence threshold — planned for the next iteration."
              />
            }
          />
          <Route
            path="*"
            element={
              <PlaceholderPage
                title="Page not found"
                note="The page you are looking for does not exist. Use the navigation above to get back."
              />
            }
          />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
